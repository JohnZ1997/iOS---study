//
//  AddAccountViewController.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/3.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

class AddAccountViewController: UIViewController, UIGestureRecognizerDelegate  {

    var delegate: sendAccountModelToViewControllerDelegate!
    
    fileprivate var accountModelArr: [AccountDetailModel]!
    
    fileprivate var viewFrame:CGRect!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewFrame = self.view.frame
        
        self.view.backgroundColor = UIColor.white
        
        //设置返回按钮样式
        let backButtonItem = UIBarButtonItem(title: "   Back", style: .plain, target: self, action: #selector(pop))
        self.navigationItem.leftBarButtonItem = backButtonItem
        
        //添加保存按钮在右侧
        let saveButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(save))
        self.navigationItem.rightBarButtonItem = saveButtonItem
        
        //初始化数据  
        //从plist文件读取数据到数组里
        let strPath = Bundle.main.path(forResource: "AccountTyoe", ofType: "plist")
        let accountDictArr = NSArray(contentsOfFile: strPath!)
        
        //将数组里的数据实例化
        accountModelArr = [AccountDetailModel]()
        for item in accountDictArr! {
            
            let accountModel = AccountDetailModel.init(dict: item as! NSDictionary)
            self.accountModelArr.append(accountModel)
            
        }
        
        
        self.addChoiceScrollView()
        
        self.addkeyBoard()
        
        addGestureRespond()

        
        
    }
    

    fileprivate var choicesScrollView: UIScrollView!
    func addChoiceScrollView() {
        
        let distanceToBoundary: CGFloat = 20

        self.choicesScrollView = UIScrollView.init(frame: CGRect(x: 0 , y: 0/*naviBarMaxY!*/, width: self.viewFrame.width, height: self.viewFrame.height))
        
        
        let widthOfButton = Double(self.viewFrame.width - distanceToBoundary * 2) / 4.00
        let rowNumber = Double(self.accountModelArr.count / 4 + 1)
        let height = widthOfButton * rowNumber + 300
        choicesScrollView.contentSize = CGSize(width: self.viewFrame.width, height: CGFloat(height))
        
        //添加按钮
        
        for item in self.accountModelArr {
            let image = UIImage.init(named: item.image!)
            let btn = UIButton.init()
            
            btn.setImage(image, for: UIControlState())
            btn.tag = Int(item.tag!)
            btn.addTarget(self, action: #selector(handleChoicesButtonsClicked), for: UIControlEvents.touchUpInside)
            
            let index = accountModelArr.index(of: item)
            let x = Double(distanceToBoundary) + Double((index!) % 4) * widthOfButton
            let y = Double((index!) / 4) * widthOfButton
            btn.frame = CGRect(x: x, y: y, width: widthOfButton, height: widthOfButton)
            self.choicesScrollView.addSubview(btn)
            self.btnArr.append(btn)
        }
        
        self.view.addSubview(self.choicesScrollView)
        
        
        self.originalContentOfSet = self.choicesScrollView.contentOffset
        
    }
    fileprivate var originalContentOfSet: CGPoint!
    
    fileprivate var btnArr:[UIButton] = {
        let _btnArr = [UIButton]()
        return _btnArr
    }()
    
    func handleChoicesButtonsClicked(_ sender: UIButton) {
        
        
        
        if self.keyBoardExist == false{
            self.basic.byValue = NSValue.init(cgPoint: CGPoint(x: 0, y: -250))
            self.keyBoard.layer.add(self.basic, forKey: nil)
            self.keyBoardExist = true
        }
        
//        self.choicesScrollView.setContentOffset(self.originalContentOfSet, animated: true)
        

        let index = sender.tag
        if btnArr[index].tag == index { // 此处进行判断，避免出现对应错误
            self.numberForRecordChoice = index
            
            self.animationForChoiceButton(index)
            
        } else {
            print("Error")
        }
        
    }
    
    /**
     点击按钮添加动画
     
     - parameter index: 记录点击的按钮是哪一个
     */
    func animationForChoiceButton(_ index: Int) {
        
        let superViewFrame = self.keyBoard.frame
        let imageViewFrame = self.keyBoard.myImageView.frame
        let naviBarMaxY = self.navigationController?.navigationBar.frame.maxY
        let y = self.choicesScrollView.contentOffset.y + 64
        let origin = CGPoint(x: superViewFrame.minX + imageViewFrame.minX, y: y + superViewFrame.minY +
            imageViewFrame.minY -
            naviBarMaxY!)// 此处对y方向位置减掉一个navigationbar因为scroollview的内部的控件的相对位置受到navibar的影响！！！！
        let size = CGSize(width: imageViewFrame.width, height: imageViewFrame.height)
        
        let frame = self.btnArr[index].frame
        //生成一个新的和被点击的button相同的imageview
        self.imageViewForAnimation.frame = CGRect(x: frame.minX - 10, y: frame.minY - 10, width: frame.width, height: frame.height)
        self.imageViewForAnimation.image = UIImage.init(named: self.accountModelArr[index].image!)
        self.choicesScrollView.addSubview(self.imageViewForAnimation)
        
        
        //动画
        UIView.animate(withDuration: 0.3, animations: {
            self.imageViewForAnimation.frame = CGRect(origin: origin, size: size)
            
            }, completion: { (Bool) in
                
                let image = UIImage.init(named: self.accountModelArr[index].image!)
                self.keyBoard.myImageView.image = image
                self.keyBoard.myTitleLabel.text = self.accountModelArr[index].title
                
                self.imageViewForAnimation.removeFromSuperview()
        })
    }
    
    //用于动画
    fileprivate var imageViewForAnimation: UIImageView = {
        let _imageView = UIImageView.init()
        return _imageView
    }()
    
    func pop() {
        
        //设置转场动画
        let animation = CATransition.init()
        animation.duration = 0.5
        animation.timingFunction = CAMediaTimingFunction.init(name: "easeInEaseOut")
        animation.type = "cube"
        animation.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(animation, forKey: "animation")
        //pop
        
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    fileprivate var numberForRecordChoice: Int = 0  //记录点击的是哪一个标签
    func save() {
        
        accountModelArr[self.numberForRecordChoice].detail = self.calculateAllMoney() as NSNumber?
        
        self.delegate.sendAccountModelToViewController(accountModelArr[self.numberForRecordChoice], index: self.indexInMainViewAccountarr)
        self.pop()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var keyBoard: KeyBoardView = {
        let _keyBoard = Bundle.main.loadNibNamed("KeyBoardView", owner: nil, options: nil)?.first as! KeyBoardView
        _keyBoard.alpha = 0.8
        return _keyBoard
    }()
    fileprivate var viewMaxY: CGFloat!
    func addkeyBoard() {
        self.viewMaxY = self.viewFrame.maxY
        self.keyBoard.frame = CGRect(x: 0, y: self.viewMaxY - 250, width: self.view.frame.width, height: 250)
        self.view.addSubview(self.keyBoard)
        for btn in self.keyBoard.allMyButtons {
            btn.addTarget(self, action: #selector(handleKeyBoardTouch), for: UIControlEvents.touchUpInside)
        }
    }
    
    fileprivate var numberArrForRecordTotalMoney = [0.00]
    fileprivate var numberForRecordIndex = 0 //记录本次编辑相加的数据个数
    fileprivate var numberForRecordDigitPlaces = -1.00
    func handleKeyBoardTouch(_ sender: UIButton) {
        switch sender.tag {
        case KeyType.zero.rawValue, KeyType.one.rawValue, KeyType.two.rawValue, KeyType.three.rawValue, KeyType.four.rawValue, KeyType.five.rawValue, KeyType.six.rawValue, KeyType.seven.rawValue, KeyType.eight.rawValue, KeyType.nine.rawValue:
            
            if self.numberForRecordDigitPlaces < -2 {
                return
            }
            //调用方法处理事件
            self.numberButtonClicked(sender.tag)
            
        case KeyType.dot.rawValue:
            self.numberForRecordDigitPlaces = -1
            return
            
        case KeyType.del.rawValue:
            self.delButtonClicked()
            
        case KeyType.plus.rawValue:
            self.plusButtonClicked()
            
        case KeyType.ok.rawValue:
            self.oKButtonClicked()
            return
            
        case KeyType.c.rawValue:
            self.reInitAllRelatedData()
            self.reEnableButtons()
            
        default:
             return
        }
        
        //更新显示钱数的label
        let labelTextStr = String.localizedStringWithFormat("¥%.2f", self.numberArrForRecordTotalMoney[numberForRecordIndex])
        self.keyBoard.myDetailLabel.text = labelTextStr
        
    }
    /**
     当点击键盘上的数字按钮时调用此方法
     根据点击的数字和当前编辑的位数来修改数据
     
     - parameter number: 点击的数字
     */
    func numberButtonClicked(_ number: Int) {
    
        var numberOfMoney = self.numberArrForRecordTotalMoney[numberForRecordIndex]
        
        if self.numberForRecordDigitPlaces >= 0 {
            numberOfMoney = numberOfMoney * 10 + Double(number)
        } else {
            numberOfMoney += Double(number) * pow(10.00, self.numberForRecordDigitPlaces)
            self.numberForRecordDigitPlaces -= 1
        }
        self.numberArrForRecordTotalMoney[numberForRecordIndex] = numberOfMoney
    }
    
    /**
     点击del按钮时调用此方法
     根据此时编辑到的位数来删除数字
     */
    func delButtonClicked() {
        
        var numberOfMoney = self.numberArrForRecordTotalMoney[numberForRecordIndex]
        if self.numberForRecordDigitPlaces < -1  {
            switch self.numberForRecordDigitPlaces {
            case -2:
                self.numberForRecordDigitPlaces += 1
                numberOfMoney = Double(Int(numberOfMoney))
                
            case -3:
                self.numberForRecordDigitPlaces += 1
                numberOfMoney = Double(Int(numberOfMoney * 10)) / 10
            default:
                return
                
            }
            
        } else if self.numberForRecordDigitPlaces == -1{
            numberOfMoney = Double(Int(numberOfMoney / 10))
            self.numberForRecordDigitPlaces = 0
        } else {
            numberOfMoney = Double(Int(numberOfMoney / 10))
        }
        
        self.numberArrForRecordTotalMoney[numberForRecordIndex] = numberOfMoney

    }
    
    /**
     点击键盘“＋”按钮时点用此方法
     清空当前显示的数据并对相应数据进行处理
     并对按钮的是否可用进行处理
     - returns:
     */
    func plusButtonClicked() {
        
        self.keyBoard.myDetailLabel.text = "¥0.00"
        self.numberForRecordIndex += 1
        self.numberArrForRecordTotalMoney.append(0.00)
        self.numberForRecordDigitPlaces = 0
        
        self.reEnableButtons()
    }
    
    
    func reEnableButtons() {
        //判断按钮是否可用，若不可以重新开启按钮可用
        if self.keyBoard.allMyButtons.first?.isEnabled == false {
            for btn in self.keyBoard.allMyButtons {
                btn.isEnabled = true
            }
        }
    }
    
    /**
     点击键盘ok按钮时点用此方法
     计算当前数组总和并显示出来
     并且置灰除“c”和“＋”其他的按钮避免出现错误
     */
    func oKButtonClicked() {
        
        if self.numberArrForRecordTotalMoney.count == 1 {
            return
        }
        
        let labelTextStr = String.localizedStringWithFormat("¥%.2f", self.calculateAllMoney())
        self.keyBoard.myDetailLabel.text = labelTextStr
        
        
        //避免用户意外点击出现错误。所以当点击ok计算总和后将除清除按钮和加号按钮外其他按钮置灰
        for btn in self.keyBoard.allMyButtons {
            if btn.tag == KeyType.plus.rawValue || btn.tag == KeyType.c.rawValue {
                continue
            } else {
                btn.isEnabled = false
            }
        }

    }
    
    /**
     当点击OK按钮时调用此方法计算出当前总钱数并显示出来
     
     - returns: 总钱数
     */
    func calculateAllMoney() -> Double {
        var allMoney = 0.00
        for item in numberArrForRecordTotalMoney {
            allMoney += item
        }
        return allMoney
    }
    
    func reInitAllRelatedData() {
        self.numberArrForRecordTotalMoney = [0.00]
        self.numberForRecordIndex = 0
        self.numberForRecordDigitPlaces = 0.00
        self.keyBoard.myDetailLabel.text = "¥0.00"
        self.indexInMainViewAccountarr = -1
    }
    
    func reSetAllBeforeAppear() {
        
        self.keyBoard.myImageView.image = UIImage.init(named: "defaultMiddle.png")
        self.keyBoard.myTitleLabel.text = ""
        self.numberForRecordChoice = 0
        
        self.reInitAllRelatedData()
        self.reEnableButtons()
        self.reEnableKeyboardIfNeeded()

    }
    
    func reEnableKeyboardIfNeeded() {
        if self.keyBoardExist == false{
            self.basic.byValue = NSValue.init(cgPoint: CGPoint(x: 0, y: -250))
            self.keyBoard.layer.add(self.basic, forKey: nil)
            self.keyBoardExist = true
        } else {
            return
        }

    }
    
//    MARK: -gesture
    fileprivate var upSwipeGestureRecognizer: UISwipeGestureRecognizer!
    fileprivate var downSwipeGestureRecognizer: UISwipeGestureRecognizer!
    func addGestureRespond() {
        
        self.upSwipeGestureRecognizer = UISwipeGestureRecognizer.init(target: self, action: #selector(handleSwipes))
        self.downSwipeGestureRecognizer = UISwipeGestureRecognizer.init(target: self, action: #selector(handleSwipes))

        self.downSwipeGestureRecognizer.delegate = self
        self.upSwipeGestureRecognizer.delegate = self
        //设置方向
        self.upSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.up
        self.downSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.down
        
        self.choicesScrollView.addGestureRecognizer(self.downSwipeGestureRecognizer)
        
        self.choicesScrollView.addGestureRecognizer(self.upSwipeGestureRecognizer)
        
    }
    
    //MARK: - 解决自己添加的代理事件和scrollview本来的代理时间冲突的问题
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    
    //MARK: -键盘动画
    fileprivate var basic: CABasicAnimation = {
        var _basic = CABasicAnimation.init(keyPath: "position")
        _basic.duration = 0.3
        _basic.fillMode = kCAFillModeForwards
        _basic.isRemovedOnCompletion = false

        return _basic
    }()
    fileprivate var keyBoardExist: Bool = true
    func handleSwipes(_ sender: UISwipeGestureRecognizer) {
        if sender.direction == UISwipeGestureRecognizerDirection.up {
            if self.keyBoardExist == true{
                self.basic.byValue = NSValue.init(cgPoint: CGPoint(x: 0, y: 250))
                self.keyBoard.layer.add(self.basic, forKey: nil)
                self.keyBoardExist = false
            } else {
                return
            }
        } else if sender.direction == UISwipeGestureRecognizerDirection.down {
            
            if self.keyBoardExist == false{
                self.basic.byValue = NSValue.init(cgPoint: CGPoint(x: 0, y: -250))
                self.keyBoard.layer.add(self.basic, forKey: nil)
                self.keyBoardExist = true
            } else {
                return
            }
            
        }
    }
    
    
    func setAccountViewWithData(_ accountModel: AccountDetailModel, index: Int) {
        self.numberForRecordChoice = accountModel.tag as! Int
        self.keyBoard.myTitleLabel.text = String(accountModel.title!)
        self.keyBoard.myImageView.image = UIImage.init(named: accountModel.image!)
        self.keyBoard.myDetailLabel.text = String.localizedStringWithFormat("¥%.2f", Double(accountModel.detail!))
        
        self.numberArrForRecordTotalMoney = [Double(accountModel.detail!)]
        self.numberForRecordIndex = 0
        self.numberForRecordDigitPlaces = 0
        
        self.reEnableKeyboardIfNeeded()
        self.reEnableButtons()
        self.indexInMainViewAccountarr = index
    }
    
    fileprivate var indexInMainViewAccountarr = -1

}
