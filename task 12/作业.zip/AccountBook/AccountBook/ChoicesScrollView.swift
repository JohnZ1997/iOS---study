//
//  ChoicesScrollView.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/6.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

class ChoicesScrollView: UIScrollView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
