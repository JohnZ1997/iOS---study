//
//  ViewController.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/3.
//  Copyright © 2016年 张皓. All rights reserved.
/**
 *  程序通过修改配置文件禁止了自动转屏 
    但是不知道如何用代码来禁止某一个页面的自动旋转 
    希望老师讲解一下
 */


import UIKit

protocol sendAccountModelToViewControllerDelegate {
    func sendAccountModelToViewController(_ model: AccountDetailModel, index: Int)
}


class ViewController: UIViewController, sendAccountModelToViewControllerDelegate {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage.init(named: "back1.jpg")
        let backgroundImageView = UIImageView.init(image: backgroundImage)
        backgroundImageView.frame = self.view.frame
                self.view.addSubview(backgroundImageView)
        self.view.sendSubview(toBack: backgroundImageView)
        
        //初始化必要的数据和设置
        self.myViewFrame = self.view.frame
        self.title = "My Account-Book"
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.view.backgroundColor = UIColor.white
        
        //为添加按钮添加响应事件
        self.myAddButton.addTarget(self, action: #selector(addAccount), for: UIControlEvents.touchUpInside)
        self.initMyScrollView()
        
    }

    
    /**
     实现代理方法进行传值
     
     1 存储账目信息
     2 将账目信息添加到时间轴上
     
     - parameter accountModel: 从添加页面传过来账目信息
     
     */
    
    
    func sendAccountModelToViewController(_ accountModel: AccountDetailModel, index: Int) {
        
        if index != -1 {
          
            
            self.reLoadIncomeAndExpend()
            
           
            
            self.accountModelArr[index] = accountModel
            let detailStr = String.localizedStringWithFormat("%.2f", Double(accountModel.detail!))
            
            self.accountViewLabelArr[index].text = accountModel.title! + "  " + detailStr
            
            
            
        } else {
            
            //将数据存入数组，，方便再次调用
            self.accountModelArr.append(accountModel)
            
            //更新scrollview
            let centerX = self.myScrollView.center.x
            
            if self.dotImageView == nil {
                let image = UIImage.init(named: "dot.png")
                self.dotImageView = UIImageView.init(image: image)
                self.dotImageView.frame = CGRect(x: centerX - 5, y: 2, width: 10, height: 10)
                self.myScrollView.addSubview(self.dotImageView)
                self.dotImageView.alpha = 0.3
            }
            
            //添加线
            let lineY = 12 + CGFloat(accountNumber) * 55
            let image = UIImage.init(named: "gray_line.png")
            let lineView = UIImageView.init(image: image)
            lineView.frame = CGRect(x: centerX - 10, y: lineY, width: 20, height: 30)
            self.myScrollView.addSubview(lineView)
            
            //存储账目信息到沙盒里
            /// /////////待实现＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃＃
            
            let accountViewY = 12 + 30 + CGFloat(accountNumber) * 55
            // 根据类型判断出支出还是收入 ，添加view
            if accountModel.type == IncomeOrExpendType.income.rawValue { //若收入
                let rect = CGRect(x: CGFloat(centerX + 12.5 - (25 * 7)), y: CGFloat(accountViewY), width: CGFloat(25.0 * 7.0), height: CGFloat(25.0))
                
                let accountView = Bundle.main.loadNibNamed("AccountViewLeft", owner: nil, options: nil)?.first as! AccountViewLeft
                
                accountView.setAll(rect, title: accountModel.title!, detail: accountModel.detail!, imageName: accountModel.image!)
                accountView.myButton.addTarget(self, action: #selector(accountViewButtonClicked), for: UIControlEvents.touchUpInside)
                
                self.myScrollView.addSubview(accountView)
                self.accountViewButtonArr.append(accountView.myButton)
                
                self.accountViewLabelArr.append(accountView.myLabel)
                
            } else if accountModel.type == IncomeOrExpendType.expend.rawValue{  //支出
                
                let rect = CGRect(x: CGFloat(centerX - 12.5), y: CGFloat(accountViewY), width: CGFloat(25.0 * 7.0), height: CGFloat(25.0))
                
                let accountViewRight = Bundle.main.loadNibNamed("AccountViewRight", owner: nil, options: nil)?.first as! AccountViewRight

                accountViewRight.setAll(rect, title: accountModel.title!, detail: accountModel.detail!, imageName: accountModel.image!)
                
                accountViewRight.myButton.addTarget(self, action: #selector(accountViewButtonClicked), for: UIControlEvents.touchUpInside)
                self.myScrollView.addSubview(accountViewRight)
                self.accountViewButtonArr.append(accountViewRight.myButton)
                self.accountViewLabelArr.append(accountViewRight.myLabel)
                
            } else {
                return
            }
            
            //设置按钮tag便于点击时分辨
            self.accountViewButtonArr[self.accountNumber].tag = self.accountNumber
            
            self.accountViewButtonArr[self.accountNumber].addTarget(self
                , action: #selector(accountViewButtonClicked), for: UIControlEvents.touchUpInside)
            
            self.lengthenTheScrollviewIfNeeded()
            self.accountNumber += 1
            
        }
  
        self.reLoadIncomeAndExpend()
       
    }
    
    //用于储存账目信息
    fileprivate var accountModelArr: [AccountDetailModel] = {
        let _accountModelArr = [AccountDetailModel]()
        return _accountModelArr
    }()
    
    fileprivate var accountViewLabelArr: [UILabel] = {
        let _accountViewLabelArr = [UILabel]()
        return _accountViewLabelArr
    }()
    
    /**
     当点击accountview的小图标时调用此方法
     弹出删除按钮和修改按钮
     
     - parameter sender: 被点击的按钮
     */
    func accountViewButtonClicked(_ sender: UIButton) {
        
        let index = sender.tag
        
        let size = self.accountViewButtonArr[index].frame.size
        let y = self.accountViewButtonArr[index].superview!.frame.origin.y
        
        let origin = CGPoint(x: self.view.center.x - size.width / 2, y: y)
        
        let originalFrame = CGRect(origin: origin, size: size)
        
        
        let finalFrame = CGRect(origin: CGPoint(x: origin.x - 70, y: origin.y), size: size)
        
        //动态添加编辑按钮
        if self.editButton == nil {
            self.editButton = UIButton.init(type: UIButtonType.custom)
            self.editButton.setBackgroundImage(UIImage.init(named: "modify.png")
                , for: UIControlState())
            self.editButton.addTarget(self, action: #selector(editAccount), for: UIControlEvents.touchUpInside)
            self.editButton.tag = index
            
            self.editButton.frame = originalFrame
            
            self.myScrollView.addSubview(self.editButton)
            
            UIView.animate(withDuration: 0.3, animations: {
                self.editButton.frame = finalFrame
            }, completion: { (Bool) in
                self.editButton.frame =  finalFrame
            }) 

        } else if index == self.editButton.tag{
            
            UIView.animate(withDuration: 0.3, animations: {
                self.editButton.frame = originalFrame
            }, completion: { (Bool) in
                self.editButton.removeFromSuperview()
                self.editButton = nil
                
            }) 
        }
        let finalFrameOfDelete = CGRect(origin: CGPoint(x: origin.x + 70, y: origin.y), size: size)
        //动态添加删除按钮
        if self.deleteButton == nil {
            self.deleteButton = UIButton.init(type: UIButtonType.custom)
            self.deleteButton.setBackgroundImage(UIImage.init(named: "delete.png")
                , for: UIControlState())
            self.deleteButton.addTarget(self, action: #selector(deleteAccount), for: UIControlEvents.touchUpInside)
            self.deleteButton.tag = index
            self.deleteButton.frame = originalFrame
            
            self.myScrollView.addSubview(self.deleteButton)
            
            UIView.animate(withDuration: 0.3, animations: {
                self.deleteButton.frame = finalFrameOfDelete
            }, completion: { (Bool) in

            }) 
            
        } else if self.deleteButton.tag == index {
            
            UIView.animate(withDuration: 0.3, animations: {
                self.deleteButton.frame = originalFrame
            }, completion: { (Bool) in
                self.deleteButton.removeFromSuperview()
                self.deleteButton = nil
            }) 
        }
    }
    
    
    fileprivate var editButton: UIButton!
    fileprivate var deleteButton: UIButton!
    
    
    func editAccount(_ sender: UIButton) { //编辑按钮的响应函数
        let index = sender.tag
        if self.addAccountViewCon?.delegate == nil {
            self.addAccountViewCon?.delegate = self
        }
        
        addAccountViewCon?.setAccountViewWithData(self.accountModelArr[index], index: index)
    
        self.navigationController?.pushViewController(addAccountViewCon!, animated: true)
        
        self.clearEditAndDeleteButtons()
        
    }
    
    
    //MARK: -此处未完成
    
    func deleteAccount(_ sender: UIButton) {  //删除按钮的响应函数
        
        self.accountViewButtonArr[sender.tag].superview!.removeFromSuperview()
        
        self.clearEditAndDeleteButtons()
        self.accountNumber -= 1
        
        
    }
    
    func clearEditAndDeleteButtons() {
        self.editButton.removeFromSuperview()
        self.deleteButton.removeFromSuperview()
        self.editButton = nil
        self.deleteButton = nil

    }
    
//    private var totalIncome: Double = 0
//    private var totalExpend: Double = 0
    
    func reLoadIncomeAndExpend() {
        
        var totalIncome: Double = 0
        var totalExpend: Double = 0

        
        for model in accountModelArr {
            if model.type == IncomeOrExpendType.income.rawValue {
                totalIncome += Double(model.detail!)
            } else {
                totalExpend += Double(model.detail!)
            }
        }
        
        self.myIncomeLabel.text = String(totalIncome)
        self.myExpendLabel.text = String(totalExpend)
    }
    
    fileprivate var accountViewButtonArr: [UIButton] = {
        var _accountViewButtonArr = [UIButton]()
        return _accountViewButtonArr
    }()
    fileprivate var dotImageView: UIImageView!
    fileprivate var accountNumber: Int = 0

    
    func lengthenTheScrollviewIfNeeded() {
        let y = self.accountViewButtonArr[(self.accountViewButtonArr.count)
            - 1].superview!.frame.maxY
        if  y > self.myScrollView.contentSize.height - 60   {
            self.myScrollView.contentSize.height += 100
        }
    }
    
    
    var myViewFrame: CGRect? = nil
    @IBOutlet var myAddButton: UIButton!
    @IBOutlet var myScrollView: UIScrollView!  //显示账目信息
    
    
    

    func initMyScrollView() {
        
        myScrollView.contentSize = CGSize(width: self.myViewFrame!.width, height: self.myViewFrame!.height)
        myScrollView.showsVerticalScrollIndicator = false
        
    }
    
    @IBOutlet var myIncomeLabel: UILabel!
    @IBOutlet var myExpendLabel: UILabel!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    var addAccountViewCon: AddAccountViewController? = {
        var _addAccountViewCon = AddAccountViewController()
        return _addAccountViewCon
    }()
    
    func addAccount() {
        
        if self.addAccountViewCon?.delegate == nil {
            self.addAccountViewCon?.delegate = self
            
        }
        self.addAccountViewCon?.reSetAllBeforeAppear()
        self.navigationController?.pushViewController(addAccountViewCon!, animated: true)
        
    }
    
    
    
    
    
    


}

