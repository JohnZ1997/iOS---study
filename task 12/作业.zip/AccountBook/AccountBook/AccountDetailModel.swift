//
//  AccountDetailModel.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/3.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

enum IncomeOrExpendType: NSNumber {
    case income = 1
    case expend = 0
}

class AccountDetailModel: NSObject {

    
    var title: String?
    var detail: NSNumber?
    var type:NSNumber?
    var image: String?
    var tag: NSNumber?

    init(dict: NSDictionary)
    {
        super.init()
        
        self.setValuesForKeys(dict as! [String : AnyObject])
    }
    
    
    
}
