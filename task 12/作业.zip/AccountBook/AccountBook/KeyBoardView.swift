//
//  KeyBoardView.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/5.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

//按钮种类，便于按钮调用
enum KeyType: Int {
    case zero = 0
    case one = 1
    case two = 2
    case three = 3
    case four = 4
    case five = 5
    case six = 6
    case seven = 7
    case eight = 8
    case nine = 9
    case del = 10
    case plus = 11
    case ok = 12
    case c = 13
    case dot = 14
}

class KeyBoardView: UIView {

    @IBOutlet var myBorderView: UIView!
    @IBOutlet var allMyButtons: [UIButton]!
    
    @IBOutlet var myImageView: UIImageView!


    
    
    @IBOutlet var myTitleLabel: UILabel!
    
    @IBOutlet var myDetailLabel: UILabel!
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        
        
        self.myBorderView.layer.borderWidth = 2
        self.myBorderView.layer.cornerRadius = 10
        
        for btn in self.allMyButtons {
            
        
            btn.layer.borderWidth = 2
            btn.layer.cornerRadius = 10
            

        }
        
    }
 

}
