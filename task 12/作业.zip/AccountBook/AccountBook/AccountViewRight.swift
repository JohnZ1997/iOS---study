//
//  AccountView.swift
//  AccountBook
//
//  Created by 张皓 on 16/10/3.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

class AccountViewRight: UIView {

    @IBOutlet var myImageView: UIImageView!
    @IBOutlet var myLabel: UILabel!
    
    @IBOutlet var myButton: UIButton!
   
    
    
    func setAll(_ frame: CGRect, title: String, detail: NSNumber, imageName: String){
        self.backgroundColor = UIColor.clear
        self.frame = frame
        let detailStr = String.localizedStringWithFormat("%.2f", Double(detail))
        self.myLabel.text = title + "  " + detailStr
        let img = UIImage.init(named: imageName)
        self.myImageView.image = img
    }
    
    

}
