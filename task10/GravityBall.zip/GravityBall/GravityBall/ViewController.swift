//
//  ViewController.swift
//  GravityBall
//
//  Created by 张皓 on 16/7/15.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit
import CoreMotion
class ViewController: UIViewController {

    var ballView: UIImageView!
    var ballVelocity: CGPoint!
    
    var myViewSize: CGSize!
    
    lazy var cmmManager: CMMotionManager = {
        let cmm = CMMotionManager()
        return cmm
        
    }()
    
    lazy var NSOptQueue: NSOperationQueue = {
        var queue = NSOperationQueue()
        return queue
    }()
    
    func initBall() {
        //初始化小球
        let img = UIImage.init(named: "ball.png")
        
        ballView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        ballView.center = self.view.center
        ballView.image = img
        
        self.view.addSubview(ballView)

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        myViewSize = self.view.bounds.size
        ballVelocity = CGPointZero

        //初始化小球
        initBall()
        
    }
    
    private var autoUpdateTimeInterval = 0.08 // 更新传感器的频率和更新小球位置的频率
    
    private var accelerateK: CGFloat = 2 //加速度放大化比例系数
    
    func startMyAccelerometer() {
        cmmManager.accelerometerUpdateInterval = autoUpdateTimeInterval
        
        if cmmManager.accelerometerAvailable {
            cmmManager.startAccelerometerUpdatesToQueue(NSOptQueue, withHandler: { (data: CMAccelerometerData?, error: NSError?) in
                //                print("\(CGFloat((data?.acceleration.x)!))")
                
                self.ballVelocity.x = self.ballVelocity.x + CGFloat((data?.acceleration.x)!) * self.accelerateK
                print("x: \(self.ballVelocity.x)")
                self.ballVelocity.y = self.ballVelocity.y - CGFloat((data?.acceleration.y)!) * self.accelerateK
                
            })
        } else {
            print("加速度传感器不可用")
        }

    }

    private var collisionK: CGFloat = 0.5 //速度衰减系数
    
    //更新小球位置
    func upDateBallLocation() {
        
        var ballCenter = self.ballView.center
        let ballR = self.ballView.bounds.size.width / 2
        
        //判断小球是否碰撞四个边界    并且模拟弹性衰减速度乘k  并且对位置进行矫正
        if ballCenter.x < ballR - 5 {
            self.ballVelocity.x = collisionK * abs(ballVelocity.x)
            
            ballCenter.x = ballR
            
        } else if ballCenter.x > self.myViewSize.width - ballR + 5 {
            self.ballVelocity.x = -collisionK * abs(ballVelocity.x)
            
            ballCenter.x = self.myViewSize.width - ballR
        }
        
        if ballCenter.y < ballR - 5{
            self.ballVelocity.y = collisionK * abs(ballVelocity.y)
            
            ballCenter.y = ballR
            
        } else if ballCenter.y > self.myViewSize.height - ballR + 5 {
            self.ballVelocity.y = -collisionK * abs(ballVelocity.y)
            
            ballCenter.y = self.myViewSize.height - ballR
        }
        
        
        //使用动画改变小球位置
        UIView.beginAnimations(nil, context: nil)
        
        UIView.setAnimationDuration(autoUpdateTimeInterval)
        self.ballView.center = CGPointMake(ballCenter.x + ballVelocity.x, ballCenter.y + ballVelocity.y)
        
        UIView.commitAnimations()
        
        //测试小球位置是否正确
/*       用于测试！！！！！！！！！！！！！！！！！！！！！！！！！！
         ballCenter = self.ballView.center
        
        print(ballCenter)
*/
    }
    
    //点击屏幕控制开始和暂停
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        if cmmManager.accelerometerActive {
            self.cmmManager.stopAccelerometerUpdates()
            stopTimer()
            
        } else {
            startMyAccelerometer()
            startTimer()
        }
        print(self.ballView.center)
    }
    
    private var timer: NSTimer!
    
    //添加计时器  使用计时器实时更新小球位置 并使用动画
    private func startTimer() {
        if timer == nil {
            timer = NSTimer.scheduledTimerWithTimeInterval(autoUpdateTimeInterval, target: self, selector: #selector(self.upDateBallLocation), userInfo: nil, repeats: true)
        }
    }
    
    //终止计时器
    private func stopTimer() {
        timer.invalidate()
        timer = nil
    }
    
    

    
    


}

