//
//  ViewController.swift
//  scrollView
//
//  Created by 张皓 on 16/5/16.
//  Copyright © 2016年 张皓. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var showBanner:Banner!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        //初始化
        showBanner = Banner.init(frame: CGRectMake(0, 0,
            UIScreen.mainScreen().bounds.width,
            UIScreen.mainScreen().bounds.height-200))
        
        showBanner.scrollDuration = 2
        
        self.view.backgroundColor = UIColor.blackColor()
//        showBanner.dataSource.addObject("sfdsf")
        self.view.addSubview(showBanner)
        
    }
    
//    @IBAction func btnChoseImg(sender: UIButton) {
//        let pickerImg:UIImagePickerController = UIImagePickerController.init()    // 判断是否允许开启本地相册
//        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
//            pickerImg.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
//            pickerImg.mediaTypes = UIImagePickerController.availableMediaTypesForSourceType(pickerImg.sourceType)!
//        }
//        
//        pickerImg.delegate = self
//        pickerImg.allowsEditing  = false
//        self.presentViewController(pickerImg, animated: true, completion: nil)
//        
//        }
//    
//    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
//        var type:String = info.indexForKey(UIImagePickerControllerMediaType)
//    }
//    
//    @IBAction func btnDuration(sender: UIButton) {
//        
//        
//        
//    }
}


